<?php
$params = [
    'website_id' => 34,
    'XINWEN'=>425,
    'GONGGAO'=>426,
    'ZHIXUN'=>427,
    'HUODONG'=>428,
];
/* $params = array_merge(
		$params,
		require(__DIR__ . '/../../data/cache/cachedData.php')
); */

return $params;