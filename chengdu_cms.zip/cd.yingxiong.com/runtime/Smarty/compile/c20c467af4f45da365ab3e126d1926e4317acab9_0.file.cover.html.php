<?php
/* Smarty version 3.1.31, created on 2017-08-25 14:26:09
  from "/mnt/hgfs/data/cmgephp/cms2/website/cd.yingxiong.com/views/site/cover.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_599fc301148f44_05297381',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c20c467af4f45da365ab3e126d1926e4317acab9' => 
    array (
      0 => '/mnt/hgfs/data/cmgephp/cms2/website/cd.yingxiong.com/views/site/cover.html',
      1 => 1503642366,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_599fc301148f44_05297381 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_myurl')) require_once '/mnt/hgfs/data/cmgephp/cms2/vendor/smarty/smarty/libs/plugins/function.myurl.php';
echo smarty_function_myurl(array('name'=>"commonMethod/get-verify"),$_smarty_tpl);
}
}
