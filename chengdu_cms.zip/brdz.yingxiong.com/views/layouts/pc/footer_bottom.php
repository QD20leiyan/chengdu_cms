<?php echo \common\widgets\downloadLink\DownloadLinkWidget::widget(); ?>
    </body>
    </html>
