<?php

?>
cover
<code><?= __FILE__ ?></code>