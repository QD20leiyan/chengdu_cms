<?php

?>
<code><?= __FILE__ ?></code>