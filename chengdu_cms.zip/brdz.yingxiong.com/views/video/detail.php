<div class="site-about row" style="margin-top: 40px">
    <h1><?= $detail['title'] ?></h1>

    <p>
        <?php echo $detail['media_url']?>
    </p>

</div>
<code><?= __FILE__ ?></code>