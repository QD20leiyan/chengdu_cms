<?php
$params = [
    'website_id' => 53,
    'H5' => 366,
    'ZHUAN_TI' => 367,
];
/* $params = array_merge(
		$params,
		require(__DIR__ . '/../../data/cache/cachedData.php')
); */

return $params;