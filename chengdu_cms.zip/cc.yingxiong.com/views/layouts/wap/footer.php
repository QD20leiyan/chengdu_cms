
<?php echo $this->render('@app/views/layouts/wap/footer_bottom.php');?>
