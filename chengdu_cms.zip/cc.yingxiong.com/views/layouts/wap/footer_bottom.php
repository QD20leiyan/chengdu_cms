<?php echo \common\widgets\downloadLink\DownloadLinkWidget::widget(); ?>
<script type="text/javascript" src="http://cdnstatic.yingxiong.com/footer/js/footer.js?{$smarty.const.VERSION}?".<?php echo VERSION?>></script>
    </body>
    </html>
