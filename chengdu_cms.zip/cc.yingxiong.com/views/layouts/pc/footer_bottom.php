<?php echo \common\widgets\downloadLink\DownloadLinkWidget::widget(); ?>
<script type="text/javascript" src="http://cdnstatic.yingxiong.com/footer/js/footer_new.js?{$smarty.const.VERSION}?<?= VERSION?>"></script>
    </body>
    </html>
