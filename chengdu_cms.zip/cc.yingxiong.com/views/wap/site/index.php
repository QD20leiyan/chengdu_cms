asdfg
<code><?= __FILE__ ?></code>